-- =========================================================================== A
-- TS_ini-pos.sql
-- ---------------------------------------------------------------------------
/*
Activité : IFT187_2022-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 12 à 15
Responsables :
emmanuel.atouga@2027.ucac-icam.com
julienne.baya@2027.ucac-icam.com
loic.nankap@2027.ucac-icam.com
joseph.nkoulou@2027.ucac-icam.com

Version : 0.2.1b (d’après AirEstrie de Christina Khnaisser)
Statut : en vigueur
Résumé : Création creation des données de tests positifs dans la base de données
-- =========================================================================== A
*/
--R:faire les insertions de test positif dans chacune des tables de la base de données

--unite
insert into Unite (sym,nom,additif,facteur_multiplicatif,sept_exposant)values
('m','mètre','2.1','24.2','13'),('s','seconde','2.2','24.2','11'),
('K','kelvin','2','24','13'),('M','molarité','2.3','24.2','1'),('A','ampère','2.1','24.2','13');

--variable
insert into variable(code,unite,nom,valref,methode)values
('VAR001','m','d','60','METH1234'),('VAR002','A','I','60','METH1235'),('VAR003','K','Q','60','METH1236'),
('VAR004','s','t','60','METH1237'),('VAR005','M','N','6','METH1237');

--norme
insert into norme (code,titre)values
('NORM01','NormeCanadienne'),('NORM02','NormeAmericaine'),('NORM03','NormeFrancaise'),
('NORM04','NormeAnglaise'),('NORM05','Normesudafricaine');

--validation
insert into validation (variable,norme,min,max)values
('VAR001','NORM01','0','200'),('VAR002','NORM02','0','300'),('VAR003','NORM03','0','400'),
('VAR004','NORM04','0','500'),('VAR005','NORM05','0','200');

--station
insert into station(code,nom,longitude,latitude,altitude,misee,fine,etat_stat)values
('STAT001','DELTA01','100','60','34','1980-01-01T00:00:00000','2030-01-01T00:00:00000','M'),
('STAT002','DELTA02','100','61','44','1985-01-01T00:00:00000','2035-01-01T00:00:00000','M'),
('STAT003','DELTA03','101','50','34','1990-01-01T00:00:00000','2040-01-01T00:00:00000','M'),
('STAT004','DELTA04','100','50','34','1995-01-01T00:00:00000','2045-01-01T00:00:00000','I'),
('STAT005','DELTA05','102','60','34','1980-01-01T00:00:00000','2030-01-01T00:00:00000','M');

--periode d'entretien
insert into periode_entretien(code)values
('STAT001'),('STAT002'),('STAT003'),('STAT004'),('STAT005');

--Mobilité
insert into mobilité(code,longitude,latitude,altitude,longitude_act,latitude_act,altitude_act,etat_station)values
('STAT001','100','60','34','101','61','35','M'),
('STAT002','100','61','44','101','62','36','M'),
('STAT003','101','50','34','102','51','35','M'),
('STAT005','102','60','34','103','61','61','M');

--Territoire
insert into territoire (code,nom,description)values
('TER001','Harlem','Arr'),('TER002','Los Angeles','Vil'),
('TER003','Queens','Arr'),('TER004','Atlanta','Mun'),('TER005','St Josephine','Mun');

--capacité
insert into capacite(station,variable)values
('STAT001','VAR003'),('STAT002','VAR003'),('STAT001','VAR002');

--distribution
insert into distribution (territoire,station)values
('TER001','STAT001'),('TER002','STAT003'),('TER003','STAT002');

--mesure
insert into mesure (station,moment,variable,valide,valeur)values
('STAT001','1995-01-10T01:30:00000','VAR003','true','25'),
('STAT001','1996-01-10T01:30:00000','VAR002','true','25'),
('STAT002','1995-01-10T01:30:00000','VAR003','true','25');

insert into mesure (station,moment,variable,valide,cause_echec)values
('STAT001','1996-01-10T01:30:00000','VAR003','true','b'),
('STAT001','1997-01-10T01:30:00000','VAR002','true','e'),
('STAT002','1998-01-10T01:30:00000','VAR003','true','s');

--Exigence
insert into Exigence_variable (code,variable,periode_valeur,periode_unite,min,max)values
('EXI001','VAR001','23','s','0','200'),
('EXI002','VAR001','23','s','0','500'),
('EXI003','VAR003','24','s','0','200');

insert into Exigence_norme (code,norme)values
('EXI01','NORM01'),('EXI002','NORM03'),('EXI003','NORM02');
/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
(2023-01-04)-R:faire les insertions de test positif dans chacune des tables de la base de données

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_ini-pos.sql
-- =========================================================================== Z
*/
