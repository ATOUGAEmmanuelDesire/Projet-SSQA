/*
-- =========================================================================== A
-- TS_inv.sql
-- ---------------------------------------------------------------------------
Activité : IFT187_2022-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 12 à 15
Responsable :
emmanuel.atouga@2027.ucac-icam.com
julienne.baya@2027.ucac-icam.com
loic.nankap@2027.ucac-icam.com
joseph.nkoulou@2027.ucac-icam.com

Version : 0.2.1b (d’après AirEstrie de Christina Khnaisser)
Statut : en vigueur
Résumé : Création des tables du schéma SSQA (système de surveillance de la qualité de l’air).
-- =========================================================================== A
*/
--R01 

-- fonction permettant d'ajouter de nouvelle unite

set schema 'SSQA';
create procedure insert_unite_new ( s Unite_Symbole ,n  Unite_Nom,a real,b real, c integer ) 
language sql as
$$
insert into unite ( sym,nom,additif,facteur_multiplicatif,sept_exposant) values( s,n,a,b,c);
$$    
;
--prolongement

set schema 'SSQA';
create  function  mesure_rep_pref ( v real , c Unite_Symbole)
returns varchar
language  sql as
$$
select
case
 --grandeur longueur
  when c='hm' then (v/10)||' km'
  when c='dam' then (v/(10^2))||' km'
  when c='m' then (v/(10^3)) ||' km'
  when c='dm' then (v/(10^4))||' km'
  when c='cm' then (v/(10^5))||' km'
  when c='mm' then (v/(10^6))||' km'
  when c='km' then  v||' km'
  
 --temperature thermodynamique
  when c='c' then (v+273.15) ||' k°'
  when c='f' then (5/9*v-32)+273.15 ||' k°'
  
 --grandeur masse
  when c='kg'  then v ||' kg'
  when c='hg'  then (v/10) ||' kg'
  when c='dag' then (v/10^2) ||' kg'
  when c='g'   then (v/10^3) ||' kg'
  when c='dg'   then (v/10^4) ||' kg'
  when c='cg'   then (v/10^5) ||' kg'
  when c='mg'   then (v/10^6) ||' kg'
end

$$; 
comment on function mesure_rep_pref is 
$$ 
cette fonction permet de rendre tout unite de mesure sous la forme d unite de mesure fondamentale correspondante
$$
;

-- R2
--R2.1 vue permettant verifier le respect de l'exigence--ok

set schema'SSQA';
create view RESPECTE_exigence as
(
  select exigence_variable.min as "min_exigence" , exigence_variable.max as "max_exigence" , validation.min as "min_validation", validation.max as "max_validation" 

  from exigence_variable join validation on(validation.variable=exigence_variable.variable)

  where  (exigence_variable.min  between validation.min and validation.max) and (exigence_variable.max  between validation.min and validation.max)	

);
comment on  view RESPECTE_exigence  is 
$$ 
Vérifie que les min et max des exigences sont compris dans l intervalle de validation 
$$

;

-- R2.2 vue permettant d'afficher les variables dont leur valref sont compris dans l'intervale de validation--ok

set schema'SSQA';
create view Valref_valide   as 
(
select 	code as "variable dont les valref sont compris dans lintervale" from variable join validation on(code=variable)
where valref between min and max
);
comment on view Valref_valide is 
$$ 
Vérifie que la valeur de référence de la variable est comprise dans l intervalle de validation
$$
;
--R3.MESURE_VALEUR_ABSCENTE

-- tache: Rendre la valeur d’une mesure facultative, en cas d’absence s’assurer d’en conserver la cause
 
 --ETAPE 1 : suppression de la contrainte not null sur la colonne valeur de la table mesure

alter table mesure alter column valeur drop not null;

--ETAPE 2 : Ajout de la colonne cause invalidite  dans la table mesure--ok

set schema 'SSQA';
create domain cause_invalidite
text
check (value similar to 'le bris du capteur'
       or value similar to 'instabilite du signal'
       or value similar to 'erreur d’encodage de la mesure'
       or value similar to 'la perte de la mesure suite a une erreur de stockage'
       or value similar to 'la perte de la mesure suite a une erreur de transmission');

alter table mesure
add column ci cause_invalidite;

-- ETAPE 3 : creation d'un automatisme permettant de s'assurer de l'invalidite d'une mesure--ok

set schema 'SSQA';

create function cause_i ()
returns trigger
language plpgsql as
$$

begin
if not exists( select ci from mesure where valeur is null or valide=false)
then return new;
else
raise info 'signaler la cause de la mesure invalide dans la column cause_mes ';
return new;
end if;
end;

$$;

create trigger controle_cause
after insert or update
on mesure
execute function cause_i();
 

/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
  2022-11-24 (LL01) : Ajouter de la table Exigence.
  2022-11-20 (LL01) : AirEstrie -> SSQA.
  2019-12-17 (CK01) : Création initiale de AirEstrie (version minimaliste).

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_inv.sql
-- =========================================================================== Z
*/
