/*
-- =========================================================================== A
-- TS_mig.sql
-- ---------------------------------------------------------------------------
Activité : IFT187_2022-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 12 à 15
Responsables :
emmanuel.atouga@2027.ucac-icam.com
julienne.baya@2027.ucac-icam.com
loic.nankap@2027.ucac-icam.com
joseph.nkoulou@2027.ucac-icam.com

Version : 0.2.1b (d’après AirEstrie de Christina Khnaisser)
Statut : en vigueur
Résumé : Apport de modifications à la base de données présente dans le script de départ
-- =========================================================================== A
*/
--R01(SI_mod): Ajouter les attributs requis par la définition en termes des unités fondamentales du SI.

alter table unite add column additif real not null ;
alter table unite add column facteur_multiplicatif real not null;
alter table unite add column sept_exposant integer not null;

--R02(SI_sym): Contraindre plus strictement les symboles

alter domain unite_symbole add 
Check(value similar to'[A,m,K,M,g,k,s,N,O,Q,C]{1}');

--R03(Validation_nom): Changer le nom de la table Seuils afin de refléter le concept d’intervalle de validation.

alter table seuils rename to validation ;

--R04(Variable_contrainte): Vérifier que les min et max des exigences sont compris dans l’intervalle de validation.

alter table validation add  constraint validation_cr3 check (min between min and max);
alter table validation add  constraint validation_cr4 check (max between min and max);

--R05(Variable_contrainte): Vérifier que le valref des exigences sont compris dans l’intervalle de validation
--(c'est ok tout fois à travailler d'avantage)

alter domain mesure_valeur add check(value between 0 and 800 );

--R06(Méthode_codification):coder les méthodes

alter table variable drop column methode;
create domain variable_methode
text
check (value similar to '[A-Z]{4}[0-9]{4}');
alter table variable add column methode variable_methode not null;

--R07(Station_service): Ajouter la date de mise en service, notamment à des fins de validation des temps de mesure.

create domain MiseE
timestamp
check(value>='1970-01-01T00:00:00000');
create domain FinE
timestamp
check(value>='1970-01-01T00:00:00000');
alter table station add column MiseE MiseE not null;
alter table station add column FinE FinE not null;
alter table station add constraint station_cc2 check(MiseE<FinE);

--R08(Station_mobilité):Modéliser la mobilité de certaines stations.

create domain Etat_station
Text
check (value similar to '[M,I]{1}');
alter table station add column Etat_stat Etat_station not null;
create table mobilité(
code station_code not null,
longitude longitude not null,
latitude latitude not null,
altitude altitude not null,
longitude_act longitude not null,
latitude_act longitude not null,
altitude_act altitude not null,
etat_station etat_station not null,
constraint mobilité_cc0 primary key (code),
constraint mobilité_cc1 foreign key (code)references station (code),
constraint mobilité_cc2 unique (longitude,latitude,altitude),
constraint mobilité_cc3 unique (longitude_act,latitude_act,altitude_act),
constraint mobilité_cc4 check (etat_station='M')
);

--R09(Validation_période):Valider que période est une unité de temps

alter table Exigence add constraint Exigence_cr3 check(periode_unite='s');

--R10(Station_nom_facultatif):Rendez le nom de la station facultatif 

alter table station drop column nom;
alter table station add column nom station_nom;

--R11(Mesure_valeur_absente):Rendre la valeur d’une mesure facultative, en cas d’absence s’assurer d’en conserver la cause.

alter table mesure drop column valeur;
alter table mesure add column valeur mesure_valeur;
create domain cause_E
text
check (value similar to '[b,i,e,s,t]{1}');
alter table mesure add column cause_echec cause_E;
create view mesure_echec as
select* from mesure where valeur= null;

--R12:Associer le texte complet du prédicat ainsi que ses dépendances fonctionnelles à l’aide d’un commentaire inscrit au catalogue (instruction COMMENT ON).

--unite 

COMMENT ON TABLE Unite is $$
unite{sym,nom,additif,facteur_multiplicatif,sept_exposant}
L’unité de mesure définie en termes des unités fondamentales du SI est identifiée
par le symbole «sym» et le nom
symsi(symboles codés): k(kg),M(mol/L),G(g/mol)
$$;

--variable 

COMMENT ON TABLE Variable is $$
variable{code,nom,unite,valref,methode}
La variable associée à un phénomène mesurable par une station est identifiée
 par le code «code», l’unité de mesure utilisée est «unite»,
la valeur de référence est «valref» et la méthode d’échantillonnage est
décrite par «methode».
df:unite->code
$$; 

--validation 

COMMENT ON TABLE Validation is $$
validation{variable,norme,min,max}
L’intervalle de validation [«min»..«max»] de la variable «variable» est établi par la norme «norme»
$$;

--station 

COMMENT ON TABLE Station is $$
station{code,nom,longitude,latitude,altitude,MiseE,FinE,Etat_station}
L’unité de mesure définie en termes des unités fondamentales du SI est identifiée
par le symbole «sym» et porte le nom «nom»
Etat_station:m(mobile),i(immobile)
$$;

--periode_entretien 

create table periode_entretien(
code station_code not null,
constraint periode_entretiencc0 primary key (code),
constraint periode_entretiencc1 foreign key (code)references station (code)
);
COMMENT ON TABLE Periode_entretien is $$
periode_entretien{code}
La periode d_entretien est identifié par un code
$$;

--capacité
 
COMMENT ON TABLE Capacite is $$
capacite{station,variable}
La station «station» a la capacité de mesurer la variable «variable»
$$;

--Territoire 

COMMENT ON TABLE Territoire is $$
territoire{code,nom,description}
Le territoire identifié par «code» est connu sous le nom «nom»
description: v(ville);r(région),a(arrondissement),m(municipalité)
$$;

--Distribution

COMMENT ON TABLE Distribution is $$
distribution{territoire,station}
La station «station» se rapporte au territoire «territoire»
$$;

--Mesure 

COMMENT ON TABLE Mesure is $$
mesure{station,moment,variable,valeur,valide,tentative,CauseE}
La valeur «valeur» de la mesure de la variable «variable» a été prise par la
station «station», au temps «moment»; sa validité est «valide»
causeE:b(le bris de capteur);i(l_instabilité du signal);e(l'erreur d'encodage de la mesure);
s(la perte de la mesure suite à une erreur de stockage);t(la perte de la mesure suite à eurreur de transmission)
$$;

--Exigence

alter table Exigence rename to Exigence_variable;
alter table Exigence_variable drop column norme;
alter table Exigence_variable add constraint exigence_variablecc0 unique (periode_unite,periode_valeur,min,max);
alter table Exigence_variable add constraint exigence_variablecr0 primary key(code);
alter table Exigence_variable add constraint exigence_variablecr1 foreign key(variable)references variable(code);
alter table Exigence_variable add constraint exigence_variablecc1 unique (code,variable,periode_unite,periode_valeur,min,max);
create table Exigence_norme(
code Exigence_code not null,
norme norme_code not null,
constraint Exigence_normecc0 primary key (norme),
constraint Exigence_normecc2 foreign key (norme)references norme(code)
);

COMMENT ON TABLE Exigence_variable is $$
exigence{code,variable,periode_valeur,periode_unite,min,max}
L’exigence_variable identifiée par le code «code» et est applicable à la variable «variable».
L’exigence est respectée si toutes les mesures de la variable «variable» sont
comprises dans l’intervalle de validation [«min»..«max»] durant toute période
de «periode_valeur» «periode_unite».
df:
$$;
COMMENT ON TABLE Exigence_norme is $$
exigence{code,norme}
exigence norme est identifiée par un un code et une norme
$$;

--R013:Ajouter la description de l'organisation hiérarchique des territoires.

create domain territoire_description
text
check (value similar to'[Arr,Vil,Reg,Mun]{3}');
alter table territoire add column description territoire_description;
/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
(2023-01-04)-R01(SI_mod): Ajouter les attributs requis par la définition en termes des unités fondamentales du SI.
Toutes les unités de mesure du SI sont définies en termes d’unités fondamentales. En pratique, il suffit d’un terme
additif (réel), d’un facteur multiplicatif (réel) et de sept exposants (entiers) — un pour chacune des unités
fondamentales (c'est ok)
(2023-01-04)-R02(SI_sym): Contraindre plus strictement les symboles(c'est ok)
(2023-01-04)-R03(Validation_nom): Changer le nom de la table Seuils afin de refléter le concept d’intervalle de validation.(c'est ok)
(2023-01-04)-R04(Variable_contrainte): Vérifier que les min et max des exigences sont compris dans l’intervalle de validation.
(2023-01-04)-R05(Variable_contrainte): Vérifier que le valref des exigences sont compris dans l’intervalle de validation
(2023-01-04)-R06(Méthode_codification):coder les méthodes(c'est ok)
(2023-01-04)-R07(Station_service): Ajouter la date de mise en service, notamment à des fins de validation des temps de mesure (c'est ok)
(2023-01-04)-R08(Station_mobilité):Modéliser la mobilité de certaines stations(c'est ok)
(2023-01-04)-R09(Validation_période):Valider que période est une unité de temps (c'est ok)
(2023-01-04)-R10(Station_nom_facultatif):Rendez le nom de la station facultatif (c'est ok)
(2023-01-04)-R11(Mesure_valeur_absente):Rendre la valeur d’une mesure facultative, en cas d’absence s’assurer d’en conserver la cause.(c'est ok) 
(2023-01-04)-R12:Associer le texte complet du prédicat ainsi que ses dépendances fonctionnelles à l’aide d’un commentaire inscrit au catalogue (instruction COMMENT ON).
unite (c'est ok)

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_inv.sql
-- =========================================================================== Z
*/


--Références :
--  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
--  [alth] https://fr.wikipedia.org/wiki/Everest
  --[altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_mig.sql
-- =========================================================================== Z

