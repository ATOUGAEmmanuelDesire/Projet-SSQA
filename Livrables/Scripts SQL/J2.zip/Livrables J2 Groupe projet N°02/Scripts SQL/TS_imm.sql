/*
-- =========================================================================== A
-- TS_imm.sql
-- ---------------------------------------------------------------------------
Activité : IFT187_2022-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 12 à 15
Responsable : 
emmanuel.atouga@2027.ucac-icam.com
julienne.baya@2027.ucac-icam.com
loic.nankap@2027.ucac-icam.com
joseph.nkoulou@2027.ucac-icam.com
Version : 0.2.1b (d’après AirEstrie de Christina Khnaisser)
Statut : en vigueur
Résumé : Création des tables du schéma SSQA (système de surveillance de la qualité de l’air).
-- =========================================================================== A
*/
--R1:créer une vue permettant de verifier le valref de variable --ok 

create view  Variable_valref as
(with A as (
select distinct code , valref 
from "SSQA".variable ) 
Select distinct  variable ,valref 
from A join "SSQA".Validation on  (code=variable)
where valref between min and max );
;
--R2:Vérifier que la valeur de référence de la variable est comprise dans l’intervalle de validation.


--vue permettant verifier la valeur de Exigence --ok

create view valeur_exigence as
(with F as ( select distinct variable , min as  u ,max as  i
    from "SSQA".exigence_variable join "SSQA".exigence_norme using (code))
   Select distinct  variable , u , i
   from F join "SSQA".Validation using (variable)
   where u between min and max and i between min and max); 

   -- Verification pour la table Exigence--ok

with F as ( select distinct norme , min as  u ,max as  i 
    from "SSQA".exigence_variable join "SSQA".exigence_norme using (code) )
   Select distinct  norme , u , i
   from F join "SSQA".Validation using (norme)
   where u between min and max and i between min and max;


-- R3:fonction permettant d'ajouter de nouvelle unite__ok 

set schema 'SSQA';



create procedure insert_unite ( s Unite_Symbole ,n  Unite_Nom,a real,b real,c integer ) 

language sql as
$$
		insert into unite( sym,nom,additif,facteur_multiplicatif,sept_exposant) values( s,n,a,b,c);

$$    




--R4:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE VARIABLE--ok

set schema 'SSQA';
create procedure insert_variable (c Variable_Code,T variable_nom,m Variable_methode, u Unite_Symbole,v Mesure_valeur)
 language sql as
$$
   insert into Variable (code,nom, methode, unite, valref) values(c ,T,m , u ,v );

$$





--R5:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE NORME--ok



set schema 'SSQA';
create procedure insert_Norme (c Norme_Code , t Norme_Titre )
 language sql as
$$

    insert into Norme (code, titre) values(c, t);
  
$$



----R6:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE VALIDATION--ok


set schema 'SSQA';

create procedure insert_Validation 
  (v Variable_Code , N Norme_code, mi Mesure_Valeur,ma Mesure_Valeur )
  language sql as
  $$
      insert into validation (variable, norme, min, max) values(v, N, mi, ma);
  $$


 ----R7:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE STATION--ok


set schema 'SSQA';

create procedure insert_Station (c Station_Code , lo Mesure_Valeur,La Mesure_Valeur,a mesure_valeur)
language sql as
$$
  insert into Station (code, longitude, latitude, altitude) values(c,lo,La,a);
$$   






----R8:FONCTION PERMETANT D' INSERER LES VALEURS DANS LA TABLE CAPACITE--ok


set schema 'SSQA';

 create procedure insert_capacite (s Station_Code , v Variable_Code)
 language sql as
 $$
   insert into Capacite (station, variable) values(s, v) ;
 $$   
;


----R9:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE  TERRITOIRE--ok



set schema 'SSQA';

create procedure insert_territoire (C Territoire_Code , N Territoire_Nom,D territoire_description)
language sql as
$$
insert into Territoire (code, nom,description) values(C, N,D);
$$   

;


----R10:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE  DISTRIBUTION



set schema 'SSQA';

create procedure insert_distribution (t Territoire_Code , s Station_Code)
language sql as
$$
  insert into distribution (territoire, station) values(t, s);
$$   


;

----R11:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE  EXIGENCE_VARIABLE--ok


set schema 'SSQA';

create procedure insert_Exigence (c Exigence_code, v Variable_Code,
pv Mesure_Valeur,pu Unite_Symbole,mi Mesure_Valeur,ma Mesure_Valeur)
 language sql as
$$
		insert into Exigence_variable (code, variable, periode_valeur, periode_unite, min, max) values (c,v,pv,pu,mi,ma);
		
$$   
;

----R12:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE  EXIGENCE_NORME--ok


set schema 'SSQA';

create procedure insert_Exigence_norme (c Exigence_code, n Norme_code)
 language sql as
$$
		insert into Exigence_norme (code,norme) values (c,n);
$$

;

----R14:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE  MESURE--ok


set schema 'SSQA';
create procedure insert_Mesure (s Station_Code, t timestamp,v Variable_Code, va Mesure_Valeur,vali Boolean)
language sql as
$$
   insert into mesure (station ,  moment , variable, valeur,valide ) values ( s, t,v,va,vali);
  
$$ ;  


----R15:CREER UNE PROCEDURE PERMETANT D' INSERER LES VALEURS DANS LA TABLE  PERIODE D'ENTRETIENT--ok

set schema 'SSQA';
create procedure insert_periode_entretien (c Station_Code)
language sql as
$$
   insert into Periode_entretien (code ) values ( c);
  
$$ ;  


/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
  2022-11-24 (LL01) : Ajouter de la table Exigence.
  2022-11-20 (LL01) : AirEstrie -> SSQA.
  2019-12-17 (CK01) : Création initiale de AirEstrie (version minimaliste).

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- SSQA_cre.sql
-- =========================================================================== Z
*/

/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
  2022-11-24 (LL01) : Ajouter de la table Exigence.
  2022-11-20 (LL01) : AirEstrie -> SSQA.
  2019-12-17 (CK01) : Création initiale de AirEstrie (version minimaliste).

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_imm.sql
-- =========================================================================== Z
*/
