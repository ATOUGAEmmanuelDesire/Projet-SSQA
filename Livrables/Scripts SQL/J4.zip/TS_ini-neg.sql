-- =========================================================================== A
-- TS_ini-neg.sql
-- ---------------------------------------------------------------------------
/*
Activité : IFT187_2022-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 12 à 15
Responsables :
emmanuel.atouga@2027.ucac-icam.com
julienne.baya@2027.ucac-icam.com
loic.nankap@2027.ucac-icam.com
joseph.nkoulou@2027.ucac-icam.com

Version : 0.2.1b (d’après AirEstrie de Christina Khnaisser)
Statut : en vigueur
Résumé : Création creation des données de tests négatifs dans la base de données
-- =========================================================================== A
*/
--R:faire les insertions de test négatif dans chacune des tables de la base de données

--unite

insert into Unite (sym,nom,additif,facteur_multiplicatif,k,m,s,kg,cd,a,mol)values--ok
('J','MOPAO','2.1','24.2','0','0','0','0','0','1','0'),
('LOLAPINOLENA','OOOOOOOOOOOOOOOOOOOOOOOOOOO','2.1','24.2','0','0','0','0','0','1','0');


--variable

insert into variable(code,nom,unite,valref,methode)values--ok
('1111111111111111111111111111111111111111111111111111111111','DIBOTO','s','237','MH'),
('2222222222222222222222222222222222222222222222222222222222','Diazote','s','12','M3H'),
('NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN','BeNONO','s','13','M4M');
--norme

insert into norme (code,titre)values--ok
('NORM11','NormeAllemande'),('NORM11','NormeAmericaine'),('NORM11','NormeFrancaise'),
('NORM11','NormeAnglaise'),('NORM11','Normesudafricaine');

--validation
insert into validation (variable,norme,min,max)values--ok
('NO2','NORM12','0','-200'),('NO2','NORM12','0','-300'),('SO2','NORM13','0','-400'),
('SO2','NORM13','0','500'),('23333333333333333333333333333333','NORM13','0','-200');

--station

insert into station(code,nom,longitude,latitude,altitude,misee,fine,etat_stat)values--ok
('1700000000000000000000000000000','DELTA01','100','60','34','1980-01-01T00:00:00000','2030-01-01T00:00:00000','Melanine'),
('1700000000000000000000000000000','DELTA02','100','61','44','1985-01-01T00:00:00000','2035-01-01T00:00:00000','Melodie'),
('1700000000000000000000000000000','DELTA03','101','50','34','1990-01-01T00:00:00000','2040-01-01T00:00:00000','Miranda'),
('2000000000000000000000000000000','DELTA04','100','50','34','1995-01-01T00:00:00000','2045-01-01T00:00:00000','Ivana'),
('2000000000000000000000000000000','DELTA05','102','60','34','1980-01-01T00:00:00000','2030-01-01T00:00:00000','Meliodas');

--periode d'entretien
insert into periode_entretien(code)values--ok
('1900000000000000000000000000000000000000'),
('1900000000000000000000000'),
('19000000000000000000000'),
('1900056566666666666666666666666666666'),
('190005555555555555555555555555555555555555555');

--Mobilité
insert into mobilité(code,longitude,latitude,altitude,longitude_act,latitude_act,altitude_act,etat_station)values--ok
('12000000000000000','100','60','34','101','62','36','M'),
('12000000000000000','100','61','44','101','62','36','M'),
('12000000000000000','101','50','34','101','62','36','M'),
('12000000000000000','102','60','34','101','62','36','M');

--Territoire
insert into territoire (code,nom,description)values--ok
('TER001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000','Harlem','Arr'),('TER0030000000000000000000000000000000000000000000000000000000000000000000000000000','Los Angeles','Vil'),
('TER002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000','Queens','Arr');

--capacité

insert into capacite(station,variable)values--ok
('20000000000000000000000000000000000000','CO2'),('20000000000000000000000000000000000000000','CO2'),('200000000000000000000000000','CO2'),
('20000000000000000000000000000000000000','CO2'),('20000000000000000000000000000000000000000','CO2'),('200000000000000000000000000','CO2');

--distribution
insert into distribution (territoire,station)values--ok
('TER001000000000000000000000000000000','14000'),('TER0010000000000000000000000000000000000000000000000000000','14000'),('TER00100000000000000000000000000000000000000000','14000');

--mesure

insert into mesure (station,moment,variable,valide,valeur)values--ok
('100000','1995-01-10T01:30:00000','CO2','true','25'),
('120000','1996-01-10T01:30:00000','CO2','true','25'),
('130000','1995-01-10T01:30:00000','CO2','true','25');

insert into mesure (station,moment,variable,valide,cause_echec)values--ok
('25000','1996-01-10T01:30:00000','CO2','true','b'),
('25000','1997-01-10T01:30:00000','CO2','true','e'),
('25000','1998-01-10T01:30:00000','CO2','true','s');

--Exigence
insert into Exigence(code,norme,variable,periode_valeur,periode_unite,min,max)values--ok
('D8','NORM01','C6H6','24','s','0','200'),
('D8','NORM01','N2','24','a','0','500'),
('D8','NORM01','CO2','24','PPM','0','200');

/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
(2023-01-04)-R:faire les insertions de test positif dans chacune des tables de la base de données

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_ini-neg.sql
-- =========================================================================== Z
*/
