-- =========================================================================== A
-- TS_ini-pos.sql
-- ---------------------------------------------------------------------------
/*
Activité : IFT187_2022-3
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 12 à 15
Responsables :
emmanuel.atouga@2027.ucac-icam.com
julienne.baya@2027.ucac-icam.com
loic.nankap@2027.ucac-icam.com
joseph.nkoulou@2027.ucac-icam.com

Version : 0.2.1b (d’après AirEstrie de Christina Khnaisser)
Statut : en vigueur
Résumé : Création creation des données de tests positifs dans la base de données
-- =========================================================================== A
*/
--R:faire les insertions de test positif dans chacune des tables de la base de données

--unite

insert into Unite (sym,nom,additif,facteur_multiplicatif,k,m,s,kg,cd,a,mol)values--ok
('A','Ampère','2.1','24.2','0','0','0','0','0','1','0'),
('kg','kilogramme','2.1','24.2','0','0','0','0','0','1','0');


--variable

insert into variable(code,nom,unite,valref,methode)values--ok
('CO2','Dioxyde de carbone','s','237','MH'),
('N2','Diazote','s','12','M3H'),
('C6H6','Benzene','s','13','M4M');
--norme

insert into norme (code,titre)values--ok
('NORM01','NormeAllemande'),('NORM02','NormeAmericaine'),('NORM03','NormeFrancaise'),
('NORM04','NormeAnglaise'),('NORM05','Normesudafricaine');

--validation
insert into validation (variable,norme,min,max)values--ok
('NO2','NORM01','0','200'),('SO2','NORM02','0','300'),('SO2','NORM03','0','400'),
('PM25','NORM04','0','500'),('O3','NORM05','0','200');

--station

insert into station(code,nom,longitude,latitude,altitude,misee,fine,etat_stat)values--ok
('17000','DELTA01','100','60','34','1980-01-01T00:00:00000','2030-01-01T00:00:00000','M'),
('18000','DELTA02','100','61','44','1985-01-01T00:00:00000','2035-01-01T00:00:00000','M'),
('19000','DELTA03','101','50','34','1990-01-01T00:00:00000','2040-01-01T00:00:00000','M'),
('20000','DELTA04','100','50','34','1995-01-01T00:00:00000','2045-01-01T00:00:00000','I'),
('21000','DELTA05','102','60','34','1980-01-01T00:00:00000','2030-01-01T00:00:00000','M');

--periode d'entretien
insert into periode_entretien(code)values--ok
('19000'),('18000'),('21000'),('10000'),('12000');

--Mobilité
insert into mobilité(code,longitude,latitude,altitude,longitude_act,latitude_act,altitude_act,etat_station)values--ok
('12000','100','60','34','101','61','35','M'),
('14000','100','61','44','101','62','36','M'),
('18000','101','50','34','102','51','35','M'),
('20000','102','60','34','103','61','61','M');

--Territoire
insert into territoire (code,nom,description)values--ok
('TER001','Harlem','Arr'),('TER002','Los Angeles','Vil'),
('TER003','Queens','Arr'),('TER004','Atlanta','Mun'),('TER005','St Josephine','Mun');

--capacité

insert into capacite(station,variable)values--ok
('20000','CO2'),('21000','CO2'),('16000','CO2'),
('10000','CO2'),('12000','CO2'),('13000','CO2');

--distribution
insert into distribution (territoire,station)values--ok
('TER001','10000'),('TER002','12000'),('TER003','14000');

--mesure

insert into mesure (station,moment,variable,valide,valeur)values--ok
('10000','1995-01-10T01:30:00000','CO2','true','25'),
('12000','1996-01-10T01:30:00000','CO2','true','25'),
('13000','1995-01-10T01:30:00000','CO2','true','25');

insert into mesure (station,moment,variable,valide,cause_echec)values--ok
('20000','1996-01-10T01:30:00000','CO2','true','b'),
('21000','1997-01-10T01:30:00000','CO2','true','e'),
('16000','1998-01-10T01:30:00000','CO2','true','s');

--Exigence
insert into Exigence(code,norme,variable,periode_valeur,periode_unite,min,max)values--ok
('D2','NORM01','C6H6','24','s','0','200'),
('D3','NORM01','N2','24','a','0','500'),
('E1','NORM01','CO2','24','h','0','200');

/*
-- =========================================================================== Z
Contributeurs :
BAYA Monera Julienne
ATOUGA II Emmanuel Désiré
NANKAP NDIZEU Loic Aurel
NKOULOU Joseph Emmanuel (Chef de groupe)

Adresse, droits d’auteur et copyright :
  Groupe Metis
  Département d’informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  NIL

Tâches réalisées :
(2023-01-04)-R:faire les insertions de test positif dans chacune des tables de la base de données

Références :
  [epp] http://info.usherbrooke.ca/llavoie/enseignement/Modules/SSQA_EPP_2022.pdf
  [alth] https://fr.wikipedia.org/wiki/Everest
  [altb] https://fr.wikipedia.org/wiki/Fosse_des_Mariannes

-- -----------------------------------------------------------------------------
-- TS_ini-pos.sql
-- =========================================================================== Z
*/
